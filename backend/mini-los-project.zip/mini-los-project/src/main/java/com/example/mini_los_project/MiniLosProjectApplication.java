package com.example.mini_los_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniLosProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniLosProjectApplication.class, args);
	}

}
